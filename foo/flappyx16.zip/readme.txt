This is the current state of my WIP Flappy Bird game.

I intend to support keyboard and mouse in addition to the joystick, but
currently, I'm having issues with my input routine trying to use the KBD.

To play the game, a joystick is required, but works in either SNES or NES mode.

I'm also working on tweaking the game physics - it's a tad too hard right now
but the original game WAS very very hard anyway, so there's that...

Enjoy!

-- ZeroByte
